
	<!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						@php
							$settings=DB::table('settings')->get();
						@endphp
						<div class="single-footer about">
							<div class="logo">
								<a href="{{route('home')}}"><img src="@foreach($settings as $data) {{asset('public'.$data->logo)}} @endforeach" alt="#" width="220px"></a>
							</div>
							
							<p class="text">@foreach($settings as $data) {!! $data->short_des !!} @endforeach</p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">@foreach($settings as $data) {{$data->phone}} @endforeach</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>My Account</h4>
							<ul>
								<li><a href="{{route('about-us')}}">About Us</a></li>
								{{-- <li><a href="#">Faq</a></li> --}}
								<li><a href="{{route('contact')}}">Contact Us</a></li>
								{{-- <li><a href="#">Help</a></li> --}}
								@php
                                    $menuCategory=App\Models\Category::where('status','active')->where('is_parent', 1)->get();
                                @endphp
								@if($menuCategory)
                                    @foreach($menuCategory as $cat)
                                        <li><a href="{{route('product-cat',$cat->slug)}}">{{ $cat->title }}</a>
                                        </li>									
                                    @endforeach
                                @endif
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								{{-- <li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li> --}}
								@if(auth()->check())
									<li><a href="{{ route('order.track') }}">Track Orders</a></li>
									<li><a href="{{route('myorders')}}">My Orders</a></li>
									<li><a href="{{ route('wishlist') }}">My Wishlist</a></li>
									<li><a href="{{ route('cart') }}">My Cart Products</a></li>
								@else
									<li><a href="{{ route('login.form') }}">Track Orders</a></li>
									<li><a href="{{ route('login.form') }}">My Orders</a></li>
									<li><a href="{{ route('login.form') }}">My Wishlist</a></li>
									<li><a href="{{ route('login.form') }}">My Cart Products</a></li>
								@endif
								<li><a href="{{route('privacy-policy')}}">Privacy Policy</a></li>
								<li><a href="{{route('terms-conditions')}}">Terms & Conditions</a></li>
								<!--<li><a href="{{route('return-refund-policy')}}">Return & Refund Policy</a></li>-->
								<!--<li><a href="{{route('exchange-policy')}}">Exchange Policy</a></li>-->
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In Tuch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>@foreach($settings as $data) {{$data->address}} @endforeach</li>
									<li>@foreach($settings as $data) {{$data->email}} @endforeach</li>
									<li>@foreach($settings as $data) {{$data->phone}} @endforeach</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<div class="social-media">
								<a target="_blank" href="https://www.facebook.com/aashigroupofcompanies"><i class="ti-facebook"> </i></a>
								<a target="_blank" href="https://www.instagram.com/aashi_rainwear_official/"><i class="ti-instagram"> </i></a>
								<a target="_blank" href="https://www.youtube.com/@newaashirainwear2779"><i class="ti-youtube"> </i></a>
								<a target="_blank" href="https://in.linkedin.com/company/aashigroup/"><i class="ti-linkedin"> </i></a>
							</div>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © {{date('Y')}} Aashi Group  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="{{asset('public/backend/img/payments.png')}}" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->
 
	<!-- Jquery -->
    <script src="{{asset('public/frontend/js/jquery.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/jquery-migrate-3.0.0.js')}}"></script>
	<script src="{{asset('public/frontend/js/jquery-ui.min.js')}}"></script>
	<!-- Popper JS -->
	<script src="{{asset('public/frontend/js/popper.min.js')}}"></script>
	<!-- Bootstrap JS -->
	<script src="{{asset('public/frontend/js/bootstrap.min.js')}}"></script>
	<!-- Color JS -->
	<!--<script src="{{asset('public/frontend/js/colors.js')}}"></script>-->
	<!-- Slicknav JS -->
	<script src="{{asset('public/frontend/js/slicknav.min.js')}}"></script>
	<!-- Owl Carousel JS -->
	<script src="{{asset('public/frontend/js/owl-carousel.js')}}"></script>
	<!-- Magnific Popup JS -->
	<script src="{{asset('public/frontend/js/magnific-popup.js')}}"></script>
	<!-- Waypoints JS -->
	<script src="{{asset('public/frontend/js/waypoints.min.js')}}"></script>
	<!-- Countdown JS -->
	<script src="{{asset('public/frontend/js/finalcountdown.min.js')}}"></script>
	<!-- Nice Select JS -->
	<script src="{{asset('public/frontend/js/nicesellect.js')}}"></script>
	<!-- Flex Slider JS -->
	<script src="{{asset('public/frontend/js/flex-slider.js')}}"></script>
	<!-- ScrollUp JS -->
	<script src="{{asset('public/frontend/js/scrollup.js')}}"></script>
	<!-- Onepage Nav JS -->
	<script src="{{asset('public/frontend/js/onepage-nav.min.js')}}"></script>
	{{-- Isotope --}}
	<script src="{{asset('public/frontend/js/isotope/isotope.pkgd.min.js')}}"></script>
	<!-- Easing JS -->
	<script src="{{asset('public/frontend/js/easing.js')}}"></script>

	<!-- Active JS -->
	<script src="{{asset('public/frontend/js/active.js')}}"></script>

	
	@stack('scripts')
	<script>
    	setTimeout(function(){
		  $('.alert').slideUp();
		},5000);
		$(function() {
		// ------------------------------------------------------- //
		// Multi Level dropdowns
		// ------------------------------------------------------ //
			$("ul.dropdown-menu [data-toggle='dropdown']").on("click", function(event) {
				event.preventDefault();
				event.stopPropagation();

				$(this).siblings().toggleClass("show");


				if (!$(this).next().hasClass('show')) {
				$(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
				}
				$(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
				$('.dropdown-submenu .show').removeClass("show");
				});

			});
		});
	  </script>